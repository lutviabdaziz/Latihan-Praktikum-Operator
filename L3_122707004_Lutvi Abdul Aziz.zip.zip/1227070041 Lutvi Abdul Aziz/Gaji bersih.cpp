#include <stdio.h>
#include <iostream>
int main (){
	int gp, gl, t, i;
	int gaji_bersih;
	
	printf ("\n=====================================\n");
	printf ("Aplikasi Penghitung Gaji Bersih Dengan Aturan");
	printf ("\n=====================================\n\n");
	printf ("Gaji Bersih Akan Dihitung Dengan Aturan :\n");
	printf ("1. Gaji Bersih 	= Gaji Pokok + Tunjangan + Gaji Lembur\n");
	printf ("2. Tunjangan 	= (10 Persen Dari Gaji Pokok)\n");
	printf ("3. Gaji Lembur	= (10 Persen Dari gaji Pokok) * Intensitas lembur\n\n");
	
	printf("Gaji Pokok 		: ");
	scanf("%d", &gp);
	printf("Intensitas Lembur 	: ");
	scanf("%d", &i);
	t = gp/10;
	printf ("Tunjangan 		: %d\n", t);
	
	gl = gp/10 * i;
	printf("Gaji Lembur       	: %d\n", gl);
	
	gaji_bersih = gp + gl + t;
	printf("\nGaji Bersihnya adalah 	: %d\n", gaji_bersih);
	
	return 0;
}
