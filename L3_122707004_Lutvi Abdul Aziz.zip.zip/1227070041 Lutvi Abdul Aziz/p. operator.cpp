#include<stdio.h>
#include <iostream>
int main (){
	int a, b, c, x;
	int persamaan;
	
	printf ("Mengetahui Hasil Dari Suatu Persamaan");
	printf ("\n ========================\n");
	
	printf  ("Persamaan ax^2 + bx + c \n\n");
	
	printf("Masukkan Nilai a = ");
	scanf("%d", &a);
	printf("Masukkan Nilai b = ");
	scanf("%d", &b);
	printf("Masukkan Nilai c = ");
	scanf("%d", &c);
	
	printf("\n Maka Persamaan Menjadi : \n");
	printf("%d x^2 + %d x + %d \n", a,b,c);
	
	printf("\n Masukkan Nilai x = ");
	scanf("%d", &x);
	
	persamaan = a*(x*x) + b*x + c;
	printf ("Hasil persamaan kuadratnya adalah : %d\n", persamaan);
	
	return 0;
}
